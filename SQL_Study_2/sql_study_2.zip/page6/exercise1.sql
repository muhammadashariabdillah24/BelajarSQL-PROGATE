-- dapatkan harga tertinggi di kolom price
SELECT MAX(price)
FROM purchases;