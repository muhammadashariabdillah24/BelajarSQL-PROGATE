-- dapatkan semua baris dengan nilai string "kaos"
SELECT *
FROM items
WHERE name LIKE "%kaos%";