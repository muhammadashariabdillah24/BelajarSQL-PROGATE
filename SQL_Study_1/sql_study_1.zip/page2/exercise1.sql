-- Akses kolom "name" dari tabel "purchases" 
SELECT name
FROM purchases;
